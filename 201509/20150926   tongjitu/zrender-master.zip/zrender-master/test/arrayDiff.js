var arrayDiff = require('../src/core/arrayDiff');
console.log(arrayDiff('fab', 'abf'));